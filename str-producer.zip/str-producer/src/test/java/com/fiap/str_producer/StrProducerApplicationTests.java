package com.fiap.str_producer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StrProducerApplicationTests {

	@Test
	void contextLoads() {
	}

}
